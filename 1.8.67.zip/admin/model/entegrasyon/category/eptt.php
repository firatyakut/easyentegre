<?php

class ModelEntegrasyonCategoryEptt extends Model
{



    public function renderAttributes($result)
    {
     return array();
    }



    public function getCategoryOptions($cat)
    {

        return false;

    }

}