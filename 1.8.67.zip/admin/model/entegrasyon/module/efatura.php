<?php

class ModelEntegrasyonModuleEfatura extends Model
{


    public function apiControl($api_data)
    {
return array('status'=>true,'message'=>'Api bilgileri başarıyla kaydedildi');
    }




}