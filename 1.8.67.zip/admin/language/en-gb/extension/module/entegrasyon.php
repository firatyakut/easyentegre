<?php
// Heading
$_['heading_title']  = 'Easy Entegre';