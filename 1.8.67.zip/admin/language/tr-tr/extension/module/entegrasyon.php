<?php
// Heading
$_['heading_title']  = 'Pazaryeri Entegrasyon';